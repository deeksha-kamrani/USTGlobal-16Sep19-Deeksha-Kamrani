package com.ustglobal.mobileapp;

import java.util.List;
import java.util.Scanner;

import com.ustglobal.mobileapp.dao.MobileDAO;
import com.ustglobal.mobileapp.dto.MobileBean;
import com.ustglobal.mobileapp.util.MobileManager;

public class App {
	public static void main(String[] args) {
	      
		System.out.println("Press 1 to show all Contacts");
		System.out.println("Press 2 to Search for Contact");
		System.out.println("Press 3 to Operate on Contact");
		
		Scanner scn = new Scanner(System.in);
		int ch = scn.nextInt();

		
		switch (ch) {
		case 1:
			
	MobileDAO dao = MobileManager.getMobileDAO();
			List<MobileBean> result = dao.getAllContacts();
			
			for(MobileBean bean : result) {
				System.out.println("Name: "+bean.getName());
				System.out.println("Number: "+bean.getNumber());
				System.out.println("Groups: "+bean.getGroups());
			}
			
			break;
		case 2:
			

			System.out.println("Press 1 to call");
			System.out.println("Press 2 to message");
			System.out.println("Press 3 to go back to main menu");
			
			Scanner scn2 = new Scanner(System.in);
			int ch2 = scn2.nextInt();
			
			

			switch (ch2) {
			case 1:
				
				MobileDAO dao1 = MobileManager.getMobileDAO();
				String name1 = scn2.next();
				MobileBean bean1 = dao1.searchContacts(name1);
				if(bean1!=null) {
					System.out.println("end the call");
				}
				
				
				break;
			case 2:
			
				MobileDAO dao5 = MobileManager.getMobileDAO();
				String name2 = scn2.next();
				String bean2=dao5.messageToTheContact(name2);
				if(bean2!=null) {
					System.out.println("message sent");
				}
				
				
			break;
			case 3:
				break;
			}
			
			break;
		case 3:
			
			System.out.println("Press 1 to add Contacts");
			System.out.println("Press 2 to delete for Contact");
			System.out.println("Press 3 to edit on Contact");
			
			Scanner scn1 = new Scanner(System.in);
			int ch1 = scn.nextInt();

			
			switch (ch1) {
			case 1:
				
				MobileDAO dao7 = MobileManager.getMobileDAO();
				String name = scn.next();
				int number =scn.nextInt();
				String groups = scn.next();
				MobileBean bean8=dao7.insertContactData(name, number, groups);
				if(bean8!=null) {
					System.out.println("successfully inserted");
				}
				
				break;
			case 2:
				
				MobileDAO dao5 = MobileManager.getMobileDAO();
				String name8 = scn.next();
				String bean3 = dao5.DeleteContactData(name8);
				
			break;
			case 3:
				
				MobileDAO dao9 = MobileManager.getMobileDAO();
				String name6 = scn.next();
				int number6 =scn.nextInt();
				String groups6 = scn.next();
				MobileBean bean9=dao9.updateContactData(name6, number6, groups6);
				if(bean9!=null) {
					System.out.println("successfully updated");
				}
				
				break;
			}
			break;
		}
}

}
