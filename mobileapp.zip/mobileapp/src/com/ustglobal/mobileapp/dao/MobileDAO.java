package com.ustglobal.mobileapp.dao;

import java.util.List;

import com.ustglobal.mobileapp.dto.MobileBean;

public interface MobileDAO {
	
	public List<MobileBean> getAllContacts();
	public MobileBean searchContacts(String name);
	
	public String DeleteContactData(String name);
	public MobileBean insertContactData(String name, int number, String groups);
	public MobileBean updateContactData(String name, int number, String groups);
	public String messageToTheContact(String name);
	
}
