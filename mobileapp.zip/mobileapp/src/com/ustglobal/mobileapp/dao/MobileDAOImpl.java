package com.ustglobal.mobileapp.dao;

import java.sql.*;
import java.util.*;

import com.ustglobal.mobileapp.dto.MobileBean;

public class MobileDAOImpl implements MobileDAO {

	@Override
	public List<MobileBean> getAllContacts() {

		String url="jdbc:mysql://localhost:3306/ContactFile?user=root&password=tiger";
		String sql= "select * from Contacts";

		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection(url);

			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);

			ArrayList<MobileBean> result = new ArrayList<MobileBean>();

			while(rs.next()) {

				MobileBean bean = new MobileBean();

				String name = rs.getString("name");
				bean.setName(name);

				int number = rs.getInt("number");
				bean.setNumber(number);

				String groups = rs.getString("groups");
				bean.setGroups(groups);
			}
			return result;
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}finally {

			try {
				if(conn!=null) {
					conn.close();
				}if(stmt!=null) {
					stmt.close();
				}if(rs!=null) {
					rs.close();
				}
			}catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}


	@Override
	public MobileBean searchContacts(String name) {

		String url="jdbc:mysql://localhost:3306/ContactFile?user=root&password=tiger";
		String sql= "select * from Contacts where name=?";

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection(url);
			pstmt = conn.prepareStatement(sql);
			
			rs = pstmt.executeQuery();

			if(rs.next()) {
				MobileBean bean = new MobileBean();
				System.out.println("name is "+bean.getName());
			}

		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}finally {
			try {
				if(conn!=null) {
					conn.close();
				}
				if(pstmt!=null) {
					pstmt.close();
				}
				if(rs!=null) {
					rs.close();
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}		

	


	@Override
	public String DeleteContactData(String name) {
		String url="jdbc:mysql://localhost:3306/ContactFile?user=root&password=tiger";
		String sql= "delete from Contacts where name=?";

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection(url);
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			int count = pstmt.executeUpdate();

			if(count>0) {
				MobileBean bean = new MobileBean();
				System.out.println(count+"rows affected");
			}
	}catch(Exception e) {
		e.printStackTrace();
		return null;
	}finally {
		try {
			if(conn!=null) {
				conn.close();
			}
			if(pstmt!=null) {
				pstmt.close();
			}
			if(rs!=null) {
				rs.close();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
		return null;
	}


	@Override
	public MobileBean insertContactData(String name, int number, String groups) {
		String url="jdbc:mysql://localhost:3306/ContactFile?user=root&password=tiger";
		String sql= "insert into Contacts values(?,?,?)";

		Connection conn = null;
		PreparedStatement pstmt = null;
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection(url);
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setInt(2, number);
			pstmt.setString(3, groups);
			int count = pstmt.executeUpdate();

			if(count>0) {
				MobileBean bean = new MobileBean();
				System.out.println(count+"rows affected");
			}
	}catch(Exception e) {
		e.printStackTrace();
		return null;
	}finally {
		try {
			if(conn!=null) {
				conn.close();
			}
			if(pstmt!=null) {
				pstmt.close();
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
		
		return null;
	}


	@Override
	public MobileBean updateContactData(String name, int number, String groups) {

		String url="jdbc:mysql://localhost:3306/ContactFile?user=root&password=tiger";
		String sql= "update Contacts set number=?,groups=? where name=?";

		Connection conn = null;
		PreparedStatement pstmt = null;
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection(url);
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(3, name);
			pstmt.setInt(1, number);
			pstmt.setString(2, groups);
			int count = pstmt.executeUpdate();

			if(count>0) {
				MobileBean bean = new MobileBean();
				System.out.println(count+"rows affected");
			}
	}catch(Exception e) {
		e.printStackTrace();
		return null;
	}finally {
		try {
			if(conn!=null) {
				conn.close();
			}
			if(pstmt!=null) {
				pstmt.close();
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
		
		return null;
	}


	@Override
	public String messageToTheContact(String name) {
		
		String url="jdbc:mysql://localhost:3306/ContactFile?user=root&password=tiger";
		String sql= "Select * from Contacts where name=?";

		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection(url);
			stmt = conn.prepareStatement(sql);
			
			rs = stmt.executeQuery(sql);

			if(rs.next()) {
				MobileBean bean = new MobileBean();
				System.out.println("name is" +bean.getName() );
			}
	}catch(Exception e) {
		e.printStackTrace();
		return null;
	}finally {
		try {
			if(conn!=null) {
				conn.close();
			}
			if(stmt!=null) {
				stmt.close();
			}
			if(rs!=null) {
				rs.close();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

		return null;
	}
}
